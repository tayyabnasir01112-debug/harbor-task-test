import json
import os
import subprocess
import sys
import tomllib


def load_report():
    output_file = "/app/output/telemetry_report.json"
    assert os.path.exists(output_file), "Expected telemetry_report.json to exist"
    with open(output_file, "r", encoding="utf-8") as report_file:
        return json.load(report_file)


def load_config():
    with open("/app/harbor.toml", "rb") as config_file:
        return tomllib.load(config_file)


def test_report_has_expected_top_level_fields():
    """Consumers get the compact JSON object they expect."""
    data = load_report()
    assert set(data) == {
        "timestamp",
        "total_services",
        "services_map",
        "status_summary",
    }
    assert isinstance(data["timestamp"], int)
    assert isinstance(data["total_services"], int)
    assert isinstance(data["services_map"], dict)
    assert isinstance(data["status_summary"], str)


def test_report_matches_enabled_services():
    """The cache entry is configured but should not show up as active."""
    data = load_report()
    config = load_config()
    active_services = [
        service for service in config.get("services", []) if service.get("enabled") is True
    ]
    disabled_services = [
        service for service in config.get("services", []) if service.get("enabled") is False
    ]

    assert data["total_services"] == len(active_services)
    assert set(data["services_map"]) == {service["name"] for service in active_services}
    assert disabled_services, "harbor.toml should include at least one disabled service"

    for service in active_services:
        reported = data["services_map"][service["name"]]
        assert reported["port"] == service["port"]
        assert reported["backend"] == service["backend"]
        assert reported["status"] == "HEALTHY"

    for service in disabled_services:
        assert service["name"] not in data["services_map"]


def test_status_summary_follows_active_count():
    """The rollup changes with the exported service count."""
    data = load_report()
    expected = "OPERATIONAL" if data["total_services"] > 0 else "DEGRADED"
    assert data["status_summary"] == expected


def test_degraded_status_when_all_services_are_disabled():
    """A quiet stack still writes a useful report instead of crashing."""
    config_path = "/app/harbor.toml"
    report_path = "/app/output/telemetry_report.json"

    with open(config_path, "rb") as config_file:
        original_config = config_file.read()
    original_report = None
    if os.path.exists(report_path):
        with open(report_path, "rb") as report_file:
            original_report = report_file.read()

    disabled_config = b"""
[harbor]
version = "v1.2.0"
env = "test"

[[services]]
name = "offline-api"
port = 9000
backend = "stub"
enabled = false
"""

    try:
        with open(config_path, "wb") as config_file:
            config_file.write(disabled_config)

        subprocess.run([sys.executable, "/app/exporter.py"], check=True)
        data = load_report()

        assert data["total_services"] == 0
        assert data["services_map"] == {}
        assert data["status_summary"] == "DEGRADED"
    finally:
        with open(config_path, "wb") as config_file:
            config_file.write(original_config)
        if original_report is not None:
            with open(report_path, "wb") as report_file:
                report_file.write(original_report)
