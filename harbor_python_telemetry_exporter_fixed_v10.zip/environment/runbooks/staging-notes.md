# Staging Notes

The staging stack intentionally keeps a few services configured but disabled.
