# Restart API

Restart the API process after validating that the local config parses cleanly.
