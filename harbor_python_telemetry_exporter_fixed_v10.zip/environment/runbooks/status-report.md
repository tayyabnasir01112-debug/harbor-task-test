# Status Report

Telemetry reports are used by operators to check service inventory quickly.
