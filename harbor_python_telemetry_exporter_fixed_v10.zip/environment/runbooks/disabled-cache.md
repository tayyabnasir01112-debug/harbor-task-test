# Disabled Cache

The cache layer can be present in configuration while remaining inactive.
