# Embedding Worker

The embedding worker should be reported only when it is enabled in Harbor config.
