# Port Map

Ports are managed in Harbor config and should not be discovered with probes.
