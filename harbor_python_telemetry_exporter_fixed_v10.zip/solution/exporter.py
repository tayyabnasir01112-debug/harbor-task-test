import json
import os
import time
import tomllib


CONFIG_PATH = "/app/harbor.toml"
OUTPUT_PATH = "/app/output/telemetry_report.json"


def build_report():
    with open(CONFIG_PATH, "rb") as config_file:
        config = tomllib.load(config_file)

    services = {}
    for service in config.get("services", []):
        if service.get("enabled") is True:
            services[service["name"]] = {
                "port": service["port"],
                "backend": service["backend"],
                "status": "HEALTHY",
            }

    service_count = len(services)
    return {
        "timestamp": int(time.time()),
        "total_services": service_count,
        "services_map": services,
        "status_summary": "OPERATIONAL" if service_count else "DEGRADED",
    }


def main():
    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as output_file:
        json.dump(build_report(), output_file, indent=2)


if __name__ == "__main__":
    main()
