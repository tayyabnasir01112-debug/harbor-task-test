#!/bin/bash
set -eo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

cp "$script_dir/exporter.py" /app/exporter.py
python3 /app/exporter.py
