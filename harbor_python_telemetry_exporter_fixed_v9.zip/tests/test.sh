#!/bin/bash
set -uo pipefail

mkdir -p /logs/verifier

uv venv /app/.venv
source /app/.venv/bin/activate
uv pip install --no-index --find-links /tests/wheels pytest==8.1.1 pytest-json-ctrf==0.5.2

python -m pytest --ctrf /logs/verifier/ctrf.json /tests/test_outputs.py -rA
rc=$?

if [ "$rc" -eq 0 ]; then
  echo 1 > /logs/verifier/reward.txt
else
  echo 0 > /logs/verifier/reward.txt
fi
