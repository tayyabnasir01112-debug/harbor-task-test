#!/bin/bash

mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt

if command -v uv >/dev/null 2>&1; then
  uv venv /app/.venv || python -m venv /app/.venv
else
  python -m venv /app/.venv
fi

if [ -f /app/.venv/bin/activate ]; then
  . /app/.venv/bin/activate
fi

python -m pip install --no-index --find-links /tests/wheels pytest==8.1.1 pytest-json-ctrf==0.5.2

python -m pytest --ctrf /logs/verifier/ctrf.json /tests/test_outputs.py -rA
rc=$?

if [ "$rc" -eq 0 ]; then
  echo 1 > /logs/verifier/reward.txt
else
  echo 0 > /logs/verifier/reward.txt
fi
