#!/bin/bash

mkdir -p /app/output

cat > /app/exporter.py <<'PY'
import json
import os
import time
import tomllib


CONFIG_PATH = "/app/harbor.toml"
OUTPUT_PATH = "/app/output/telemetry_report.json"


def collect_services(config):
    services = {}
    for service in config.get("services", []):
        if service.get("enabled") is True:
            services[service["name"]] = {
                "port": service["port"],
                "backend": service["backend"],
                "status": "HEALTHY",
            }
    return services


def build_report():
    with open(CONFIG_PATH, "rb") as config_file:
        config = tomllib.load(config_file)

    services = collect_services(config)
    return {
        "timestamp": int(time.time()),
        "total_services": len(services),
        "services_map": services,
        "status_summary": "OPERATIONAL" if services else "DEGRADED",
    }


def main():
    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as output_file:
        json.dump(build_report(), output_file, indent=2)


if __name__ == "__main__":
    main()
PY

python3 /app/exporter.py || true
